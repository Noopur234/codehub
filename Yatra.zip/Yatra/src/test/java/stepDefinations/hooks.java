package stepDefinations;
import SeleniumCucumberPrjct.Yatra.base;
import io.cucumber.java.After;
public class hooks extends base{
 
	@After("@smokeTest")
	public void afterSmokeTest()
	{
		dr.close();
	}
}
