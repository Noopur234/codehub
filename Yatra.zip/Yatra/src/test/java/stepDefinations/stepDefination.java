package stepDefinations;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import java.sql.Driver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.openqa.selenium.chrome.ChromeDriver;

import SeleniumCucumberPrjct.Yatra.base;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class stepDefination extends base{
    @Given("^Validate the browser$")
	public void validate_the_browser() throws Throwable 
    {
    	dr=base.getDriver();       //making driver obj accessible throughtout
	}
    @When("^Browser is triggered$")
	public void browser_is_triggered() throws Throwable 
    {
    	String URL=base.getGlobalProperty("url");
    	dr.get(URL);                   //using global variables
    	dr.manage().window().maximize();
	}
    @Then("^Check if browser is displayed$")
    public boolean check_if_browser_is_displayed() throws Throwable 
    {  
    	if(dr.getCurrentUrl()!=null)
    		return true;
    	else
    		return false;
	}
	@Given("^User is on Yatra Home page$")
	public void User_is_on_Yatra_Home_page() throws Throwable
	{
		String actualTitle = dr.getTitle();
    	String expectedTitle ="Flight, Cheap Air Tickets , Hotels, Holiday, Trains Package Booking - Yatra.com";
    	if(actualTitle.equalsIgnoreCase(expectedTitle))
			System.out.println("User is on Yatra Home page");
		else
			System.out.println("User is on Yatra Home page");	
	}
    @When("^User select MyAccount tab$")
    public void User_select_MyAccount_tab() throws Throwable
    {
    	JavascriptExecutor js = (JavascriptExecutor) dr;
    	js.executeScript("document.getElementsByClassName('dropdown-toggle').item(0).click",1);
    }
    @And("^User select Login subtab$")
    public void User_select_Login_subtab() throws Throwable
    {
    	dr.findElement(By.xpath("//li[@id='userLoginBlock']/div//li/a[@id='signInBtn']")).click();   	
    }
    @Then("^User Lands on Yatra Login page$")
    public void User_Lands_on_Yatra_Login_page() throws Throwable
    {
    	String actualTitle = dr.getTitle();
    	String expectedTitle ="Yatra Account";
    	if(actualTitle.equalsIgnoreCase(expectedTitle))
			System.out.println("User is on Yatra Login page");
		else
			System.out.println("User is on Yatra Login page"); 	
    }       
    @Given("^User is on Yatra Login page$")
    public void user_is_on_yatra_login_page() throws Throwable
    {
    	String actualTitle = dr.getTitle();
    	String expectedTitle ="Yatra Account";
    	if(actualTitle.equalsIgnoreCase(expectedTitle))
			System.out.println("User is on Yatra Login page");
		else
			System.out.println("User is on Yatra Login page");
    }
    @And("^EmailMobile Number field is displayed$")
    public void emailmobile_number_field_is_displayed() throws Throwable
    {
    	WebElement emailfield = dr.findElement(By.xpath("//input[@id='login-input']"));
    	if(emailfield.isDisplayed())
    		System.out.println("EmailId field is displayed");
		else
			System.out.println("EmailId field is not displayed");
    }
    @When("^User enters Email Id (.+)$")
    public void user_enters_email_id(String emailid) throws Throwable 
    {
    	dr.findElement(By.xpath("//input[@id='login-input']")).sendKeys(emailid);
    }
    @And("^Continue button is clicked$")
    public void continue_button_is_clicked() throws Throwable 
    {
    	dr.findElement(By.xpath("//button[text()='Continue']")).click();
    }
    @And("^User enters Password (.+)$")
    public void user_enters_password(String pwd) throws Throwable 
    {
    	dr.findElement(By.xpath("//input[@id='login-password']")).sendKeys(pwd);  
    }
    @And("^Login button is clicked$")
    public void login_button_is_clicked() throws Throwable 
    {
    	dr.findElement(By.xpath("//button[@id='login-submit-btn']")).click();
    }
    @Then("^User successfully logsin$")
    public void user_successfully_logsin() throws Throwable
    {
    	JavascriptExecutor js = (JavascriptExecutor) dr;
    	js.executeScript("document.getElementsByClassName('dropdown-toggle loginUserName').item(0).text",1);
    }
    @Then("^Error is displayed (.+)$")
    public void error_is_displayed_something(String err) throws Throwable 
    {
    	System.out.println(err);
    }   
}
