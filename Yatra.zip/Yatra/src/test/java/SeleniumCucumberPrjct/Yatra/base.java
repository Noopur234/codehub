package SeleniumCucumberPrjct.Yatra;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class base {
public static WebDriver dr;
public static Properties prop;


	public static WebDriver getDriver() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\chromedriver.exe");
    	dr = new ChromeDriver(); 
    	return dr;
	}
	
	public static String getGlobalProperty(String req) throws IOException 
	{
		String result = null;
		prop = new Properties();
		
		FileInputStream fis = new FileInputStream("C:\\Users\\admin\\Downloads\\Noopur_Selenium_Prjct\\Yatra\\src\\test\\java\\SeleniumCucumberPrjct\\Yatra\\global.properties");
		prop.load(fis);
		
		if(req=="url")
		{
		 result = prop.getProperty("url");
		}
		return result;
	}
}
